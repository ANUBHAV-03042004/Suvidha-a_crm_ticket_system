import express from 'express';
import Ticket from '../models/Ticket.js';
import { ensureAuthenticated } from '../middleware/auth.js';
import { v2 as cloudinary } from 'cloudinary';
import { CloudinaryStorage } from 'multer-storage-cloudinary';
import multer from 'multer';
import editTicketRoutes from './editticket.js';

const router = express.Router();

// Cloudinary storage setup
const storage = new CloudinaryStorage({
  cloudinary,
  params: {
    folder: 'tickets',
    allowed_formats: ['jpg', 'jpeg', 'png'],
    public_id: (req, file) => `${Date.now()}-${file.originalname}`,
  },
});

const upload = multer({
  storage,
  fileFilter: (req, file, cb) => {
    const filetypes = /jpeg|jpg|png/;
    const extname = filetypes.test(file.originalname.toLowerCase());
    const mimetype = filetypes.test(file.mimetype);
    if (extname && mimetype) {
      return cb(null, true);
    }
    cb(new Error('Only JPEG, JPG, or PNG images are allowed.'));
  },
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
});

router.use(editTicketRoutes);

// GET: Fetch all tickets for the authenticated user
router.get('/', ensureAuthenticated, async (req, res) => {
  try {
    console.log('GET /api/tickets - User:', req.user?._id || 'No user');
    const tickets = await Ticket.find({ userId: req.user._id });
    console.log('Fetched tickets:', tickets);
    res.status(200).json(tickets);
  } catch (err) {
    console.error('Error fetching tickets:', { name: err.name, message: err.message, stack: err.stack });
    res.status(500).json({ error: 'Server error', details: err.message });
  }
});

// POST: Create a new ticket
router.post(
  '/',
  ensureAuthenticated,
  upload.fields([{ name: 'invoice' }, { name: 'product_image' }]),
  async (req, res) => {
    try {
      console.log('POST /api/tickets - User:', req.user?._id || 'No user', 'Body:', req.body, 'Files:', req.files);
      const { issue, description } = req.body;
      if (!issue || !description) {
        console.log('Missing required fields:', { issue, description });
        return res.status(400).json({ error: 'Issue and description are required.' });
      }
      if (!req.user?._id) {
        console.log('No user ID in session');
        return res.status(401).json({ error: 'User not authenticated' });
      }

      const invoiceUrl = req.files['invoice'] ? req.files['invoice'][0].path : null;
      const productImageUrl = req.files['product_image'] ? req.files['product_image'][0].path : null;

      const newTicket = new Ticket({
        userId: req.user._id,
        issue,
        description,
        invoice: invoiceUrl,
        product_image: productImageUrl,
      });

      const savedTicket = await newTicket.save();
      console.log('Saved ticket:', savedTicket);
      res.status(201).json(savedTicket);
    } catch (err) {
      console.error('Error saving ticket:', { name: err.name, message: err.message, stack: err.stack });
      if (err.message.includes('Only JPEG, JPG, or PNG')) {
        res.status(400).json({ error: err.message });
      } else if (err.name === 'ValidationError') {
        console.log('MongoDB validation error:', err.errors);
        res.status(400).json({ error: err.message });
      } else {
        res.status(500).json({ error: 'Server error', details: err.message });
      }
    }
  }
);

export default router;