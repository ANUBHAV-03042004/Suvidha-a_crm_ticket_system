// const crypto = require('crypto');
import crypto from 'crypto';
console.log(crypto.randomBytes(32).toString('hex'));